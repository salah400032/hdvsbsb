from flask import Flask, render_template, request, send_from_directory
import os
import subprocess
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
HLS_FOLDER = "hls"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(HLS_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/upload', methods=['POST'])
def upload():
    if 'video' not in request.files:
        return "No video uploaded", 400

    file = request.files['video']
    watermark_text = request.form.get("watermark", "WATERMARK")

    if file.filename == '':
        return "No selected file", 400

    filename = secure_filename(file.filename)
    input_path = os.path.join(UPLOAD_FOLDER, filename)
    file.save(input_path)

    output_folder = os.path.join(HLS_FOLDER, filename.split('.')[0])
    os.makedirs(output_folder, exist_ok=True)

    output_path = os.path.join(output_folder, "output.m3u8")
    command = [
        "ffmpeg", "-i", input_path,
        "-vf", f"drawtext=text='{watermark_text}':fontcolor=white:fontsize=24:x=10:y=10",
        "-c:a", "aac", "-c:v", "libx264", "-f", "hls",
        "-hls_time", "10", "-hls_playlist_type", "vod",
        output_path
    ]

    subprocess.run(command)

    return render_template("result.html", video=f"{filename.split('.')[0]}/output.m3u8")

@app.route('/hls/<path:filename>')
def stream(filename):
    return send_from_directory('hls', filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')